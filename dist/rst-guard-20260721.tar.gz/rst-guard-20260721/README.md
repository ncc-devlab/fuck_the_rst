# SSH RST Guard

这是一个 TC ingress eBPF 过滤器：进入本机的 TCP RST 只有在携带指定的尾部 TCP 选项时才会被接受，否则丢弃。过滤器只检查源端口或目的端口为 `22` 的 TCP 流量。

## 一键安装（推荐）

在开发机打包（含预编译 `.o`）：

```sh
make pack
# 产物: dist/rst-guard-YYYYMMDD.tar.gz
```

在目标机：

```sh
tar xzf rst-guard-YYYYMMDD.tar.gz
cd rst-guard-YYYYMMDD
sudo ./install.sh
```

安装脚本会：

1. 安装依赖（Ubuntu/Debian 上缺 clang 时自动 `apt install`）
2. 安装文件到 `/opt/rst-guard`
3. 写入配置 `/etc/rst-guard/config`
4. 挂载 TC 过滤器并启用守护进程 `rst-guard.service`

守护进程 `rst-guardd` 每 5 秒扫描网卡：发现接口缺失 `clsact` / ingress / egress 过滤器时会自动重新挂载（应对网卡重启、热插拔）。

常用命令：

```sh
sudo systemctl status rst-guard
sudo /opt/rst-guard/rst-guardd status
sudo /opt/rst-guard/rst-guardd once      # 立即重挂
sudo ./uninstall.sh                     # 卸载服务并 detach
```

配置 `/etc/rst-guard/config`：

```sh
IFACES=""          # 空=自动所有非 lo 网卡；或 "eth0 ens3"
MODE="both"        # both | ingress | egress
INTERVAL=5
```

## 魔数格式

允许的最后一个 TCP option 为：

```text
kind = 254                 # TCP experimental option
length = 10
data = 52 53 54 47 55 41 52 44  # ASCII "RSTGUARD"
pad  = 00 00               # 4-byte alignment after the option
```

入口侧检查 TCP options 的**最后 12 字节**是否恰好是该块（`254,10,RSTGUARD,0,0`）。客户端出口程序写入的也是这一块。普通 RST 不会被接受。

## 构建与挂载

Ubuntu 24 需要安装 LLVM/eBPF 编译工具：

```sh
sudo apt update
sudo apt install clang llvm libbpf-dev linux-libc-dev iproute2
```

Makefile 会自动选择 `clang` 或版本化的 `clang-18`、`clang-17` 等命令，并根据当前机器架构选择 x86 或 arm64。

```sh
make
IFACE=eth0
sudo tc qdisc replace dev "$IFACE" clsact
sudo tc filter replace dev "$IFACE" ingress bpf da obj rst_guard.bpf.o sec classifier
```

`IFACE` 必须替换为实际网卡名称，可用 `ip -br link` 查看。`bpf` 是 `tc` 的过滤器类型，不是需要单独运行的命令；不能把上面的过滤器命令拆成
`tc filter replace ... ingress` 和 `bpf da obj ...` 两条命令。前者会报
`Filter kind and protocol must be specified`，后者会报 `bpf: command not found`。

客户端还要在出口方向挂载同一个对象。它会把本机 TCP 栈生成的、无数据的 IPv4 SSH RST 改写为带 `RSTGUARD` option 的 RST；入口规则则继续丢弃没有魔数的远端 RST：

```sh
sudo tc filter replace dev "$IFACE" egress bpf da obj rst_guard.bpf.o sec classifier/egress
```

确认过滤器已经挂载：

```sh
sudo tc filter show dev "$IFACE" ingress
sudo tc filter show dev "$IFACE" egress
```

出口程序只处理本机生成的 IPv4、无 TCP payload、端口为 22 的 RST。它不会把普通出站数据包改成 RST，也不会阻止本机释放连接。

卸载：

```sh
sudo tc filter del dev "$IFACE" ingress
sudo tc filter del dev "$IFACE" egress
sudo tc qdisc del dev "$IFACE" clsact
```

把 `IFACE` 换成实际网卡。入口只丢无魔数的 SSH RST；出口改写本机生成的 IPv4 SSH RST。FIN 与普通 TCP 释放不受影响。

## 限制

- 这是按网卡 ingress 方向过滤，不是按进程过滤；目标是端口 22 的所有 TCP RST。
- 程序只解析 Ethernet、单层 VLAN、IPv4 和 IPv6 的直接 TCP；IPv6 扩展头、隧道和多层 VLAN 会放行，不会误丢弃。
- 服务端需要发送端能够构造带实验性 TCP option 的 RST；普通 `sshd`、内核 TCP 栈或防火墙生成的远端 RST 通常不会自动带此 option。客户端挂载出口程序后，本机生成的符合条件的 IPv4 RST 会自动改写。
- 客户端出口改写支持 IPv4 的无数据 RST；IPv6、带 payload、GSO/分片或已有复杂封装的 RST 会保持原样。
- 如果想保护多个 SSH 端口，应修改 `SSH_PORT`；不要把该规则用于所有 TCP 端口。
